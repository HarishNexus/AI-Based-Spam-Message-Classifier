# AI-Based Spam Message Classifier

A small Python machine-learning prototype that predicts whether an SMS message is **Spam** or **Normal**.

## 1. Objective
- Classify text messages into Spam and Normal categories.
- Demonstrate how a machine-learning model can process text.
- Evaluate predictions using a held-out test set and standard classification metrics.

## 2. User
Mobile phone users who want a simple demonstration tool for identifying unwanted or suspicious SMS messages.

## 3. Technology used
- **Python**
- **Scikit-learn** — machine-learning library
- **TF-IDF Vectorizer** — converts text into numerical features
- **Logistic Regression** — classification algorithm

No external AI API or secret API key is required. The model runs locally.

## 4. Project files
```text
AI-Based-Spam-Message-Classifier/
├── main.py
├── requirements.txt
├── README.md
├── data/
│   └── sms_sample.csv
└── examples/
    ├── example_inputs.txt
    └── example_outputs.txt
```

## 5. How it works
1. Load labeled SMS messages from `data/sms_sample.csv`.
2. Split the dataset into training and test sets.
3. Convert message text to TF-IDF features.
4. Train a Logistic Regression classifier.
5. Evaluate it on test messages using accuracy, precision, recall, F1-score, and a confusion matrix.
6. Predict a label for example messages or text entered by the user.

## 6. Setup and run

### Windows
Open a terminal in the project folder and run:

```bash
py -m venv .venv
.venv\Scripts\activate
py -m pip install -r requirements.txt
py main.py
```

If PowerShell blocks activation, use Command Prompt or run the install command without activating the environment.

### macOS / Linux / GitHub Codespaces
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python main.py
```

### Google Colab
Run this in a notebook cell:
```python
!pip install scikit-learn
```
Then upload the project files (including `data/sms_sample.csv`) or clone your public repository and run `main.py` from the project directory.

## 7. Example input and output

**Input**
```text
Congratulations! You have won a free prize. Claim it now!
```

**Expected example label**
```text
SPAM
```

**Input**
```text
Hi, are we still meeting at the library tomorrow?
```

**Expected example label**
```text
NORMAL
```

These are illustrative examples. Actual predictions depend on the training data and learned model; they are not guaranteed.

## 8. Evaluation approach
The program holds out 25% of the sample messages for testing and prints:
- **Accuracy** — fraction of test messages classified correctly.
- **Precision** — among messages predicted as spam, the fraction actually labeled spam.
- **Recall** — among actual spam messages, the fraction detected.
- **F1-score** — a combined measure of precision and recall.
- **Confusion matrix** — counts correct and incorrect predictions.

The included dataset is small and intended only to demonstrate the workflow. Do not treat its score as evidence of real-world performance. For a stronger evaluation, use a larger labeled dataset such as the public **UCI SMS Spam Collection**, document the source, and evaluate on held-out data.

## 9. Constraints and responsible use
- Small sample data may not represent real-world messages.
- Messages can be misclassified; a “Normal” result does not prove a message is safe.
- Do not enter private or sensitive messages into a public demo.
- Evaluate on unseen data and avoid claiming perfect accuracy.

## 10. Example interactive session
```text
Message> Congratulations! Claim your free prize now
Prediction: SPAM

Message> Can you send me the lecture notes?
Prediction: NORMAL

Message> exit
Exiting classifier.
```

## 11. Assignment summary
**Use case:** SMS text classification  
**Model/library:** Logistic Regression and Scikit-learn  
**Input:** SMS text  
**Output:** Spam or Normal  
**Evaluation:** Accuracy, precision, recall, F1-score, confusion matrix  
**API keys:** None required
