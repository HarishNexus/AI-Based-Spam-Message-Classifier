"""
AI-Based Spam Message Classifier
A small machine-learning prototype using TF-IDF and Logistic Regression.
Run: python main.py
"""

from pathlib import Path
import csv
import sys

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

BASE_DIR = Path(__file__).resolve().parent
DATASET_PATH = BASE_DIR / "data" / "sms_sample.csv"


def load_dataset(path: Path):
    """Load SMS text and labels from a CSV file."""
    messages, labels = [], []
    with path.open("r", encoding="utf-8", newline="") as csv_file:
        reader = csv.DictReader(csv_file)
        required_columns = {"message", "label"}
        if not reader.fieldnames or not required_columns.issubset(reader.fieldnames):
            raise ValueError("Dataset must contain 'message' and 'label' columns.")

        for row in reader:
            message = (row.get("message") or "").strip()
            label = (row.get("label") or "").strip().lower()
            if message and label in {"spam", "normal"}:
                messages.append(message)
                labels.append(label)

    if len(messages) < 8 or len(set(labels)) < 2:
        raise ValueError("Dataset needs at least 8 valid messages and both labels: spam and normal.")
    return messages, labels


def build_model():
    """Create a text-processing and classification pipeline."""
    return Pipeline([
        ("tfidf", TfidfVectorizer(lowercase=True, stop_words="english")),
        ("classifier", LogisticRegression(max_iter=1000, random_state=42)),
    ])


def main():
    if not DATASET_PATH.exists():
        print(f"Dataset not found: {DATASET_PATH}")
        print("Make sure data/sms_sample.csv exists.")
        sys.exit(1)

    try:
        messages, labels = load_dataset(DATASET_PATH)
        X_train, X_test, y_train, y_test = train_test_split(
            messages,
            labels,
            test_size=0.25,
            random_state=42,
            stratify=labels,
        )
    except (ValueError, OSError) as error:
        print(f"Could not prepare dataset: {error}")
        sys.exit(1)

    model = build_model()
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    print("\n=== AI-Based Spam Message Classifier ===")
    print(f"Dataset messages: {len(messages)}")
    print(f"Training messages: {len(X_train)}")
    print(f"Testing messages: {len(X_test)}")
    print(f"Test accuracy: {accuracy_score(y_test, predictions):.2%}")
    print("\nClassification report:")
    print(classification_report(y_test, predictions, labels=["normal", "spam"], zero_division=0))
    print("Confusion matrix (rows = actual [normal, spam]; columns = predicted [normal, spam]):")
    print(confusion_matrix(y_test, predictions, labels=["normal", "spam"]))

    print("\n--- Example predictions ---")
    examples = [
        "Congratulations! You have won a free prize. Claim it now!",
        "Hi, are we still meeting at the library tomorrow?",
    ]
    for message in examples:
        prediction = model.predict([message])[0]
        print(f"Input: {message}")
        print(f"Output: {prediction.upper()}\n")

    print("Enter your own SMS message to test the model.")
    print("Type 'exit' to stop.")
    while True:
        try:
            user_message = input("Message> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting classifier.")
            break

        if user_message.lower() == "exit":
            print("Exiting classifier.")
            break
        if not user_message:
            print("Please enter a non-empty message.")
            continue

        prediction = model.predict([user_message])[0]
        print(f"Prediction: {prediction.upper()}")
        print("Note: This is a prediction, not a guarantee that a message is safe.\n")


if __name__ == "__main__":
    main()
